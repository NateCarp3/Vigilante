// Vigilante theme — cart drawer, quick add, product options
(function () {
  const V = window.Vigilante || {};
  const drawer = document.querySelector('[data-cart]');
  const linesEl = document.querySelector('[data-cart-lines]');
  const subtotalEl = document.querySelector('[data-cart-subtotal]');
  const shipEl = document.querySelector('[data-ship-msg]');

  const money = (cents) => {
    const n = cents / 100;
    return '$' + (Number.isInteger(n) ? n.toLocaleString('en-US') : n.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }));
  };
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const json = (r) => { if (!r.ok) return r.json().then((e) => { throw e; }); return r.json(); };

  function renderCart(cart) {
    document.querySelectorAll('[data-cart-count]').forEach((el) => { el.textContent = cart.item_count; });
    if (!linesEl) return;
    if (!cart.items.length) {
      linesEl.innerHTML = '<div class="cart-empty"><p>It\'s quiet in here.</p><button class="btn btn-outline" data-close-cart>KEEP SHOPPING</button></div>';
    } else {
      linesEl.innerHTML = cart.items.map((it) => `
        <div class="cart-line">
          ${it.image ? `<img src="${esc(it.image)}&width=160" alt="" width="72" height="72">` : ''}
          <div class="cart-line-info">
            <strong>${esc(it.product_title.toUpperCase())}</strong>
            ${it.variant_title && it.variant_title !== 'Default Title' ? `<span class="muted">${esc(it.variant_title)}</span>` : ''}
            <span class="muted">Qty: ${it.quantity} · ${money(it.final_line_price)}</span>
          </div>
          <button class="link-btn" data-remove="${esc(it.key)}">Remove</button>
        </div>`).join('');
    }
    subtotalEl.textContent = money(cart.total_price);
    if (shipEl && V.freeShipping) {
      shipEl.hidden = !cart.items.length;
      shipEl.textContent = cart.total_price >= V.freeShipping
        ? 'You\'ve got free shipping!'
        : 'You\'re ' + money(V.freeShipping - cart.total_price) + ' away from free shipping.';
    }
  }

  const refresh = () => fetch(V.routes.cart, { headers: { Accept: 'application/json' } }).then(json).then(renderCart);
  function open() { if (!drawer) return; drawer.hidden = false; document.body.style.overflow = 'hidden'; }
  function close() { if (!drawer) return; drawer.hidden = true; document.body.style.overflow = ''; }

  function addToCart(id, quantity) {
    return fetch(V.routes.cartAdd, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
      body: JSON.stringify({ items: [{ id: Number(id), quantity: Number(quantity) || 1 }] })
    }).then(json).then(refresh).then(open);
  }

  document.addEventListener('click', (e) => {
    const t = e.target.closest('[data-open-cart],[data-close-cart],[data-remove],[data-quick-add]');
    if (!t) return;
    if (t.matches('[data-open-cart]')) { if (drawer) { e.preventDefault(); refresh().then(open); } }
    else if (t.matches('[data-close-cart]')) { close(); }
    else if (t.matches('[data-remove]')) {
      fetch(V.routes.cartChange, { method: 'POST', headers: { 'Content-Type': 'application/json', Accept: 'application/json' }, body: JSON.stringify({ id: t.dataset.remove, quantity: 0 }) })
        .then(json).then(renderCart);
    } else if (t.matches('[data-quick-add]')) {
      t.disabled = true;
      addToCart(t.dataset.quickAdd, 1).catch((err) => alertError(t, err)).finally(() => { t.disabled = false; });
    }
  });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape' && drawer && !drawer.hidden) close(); });

  function alertError(el, err) {
    const msg = (err && (err.description || err.message)) || 'Could not add to cart.';
    const box = el.closest('form') && el.closest('form').querySelector('[data-form-error]');
    if (box) { box.hidden = false; box.textContent = msg; } else { el.textContent = 'TRY AGAIN'; }
  }

  // Product page: option buttons pick the matching variant
  const pdp = document.querySelector('[data-product]');
  if (pdp) {
    const product = JSON.parse(pdp.parentElement.querySelector('[data-product-json]').textContent);
    const form = pdp.querySelector('[data-product-form]');
    const idInput = form.querySelector('[data-variant-id]');
    const priceEl = pdp.querySelector('[data-price]');
    const addBtn = form.querySelector('[data-add-btn]');
    const qtyInput = form.querySelector('[data-qty-input]');
    const groups = Array.from(pdp.querySelectorAll('[data-option-group]'));
    const mainImg = pdp.querySelector('.gallery-main img');

    const selected = () => groups.map((g) => { const on = g.querySelector('.size-btn.on'); return on ? on.dataset.optionValue : null; });

    function update() {
      const sel = selected();
      const variant = product.variants.find((v) => v.options.every((o, i) => o === sel[i]));
      groups.forEach((g, gi) => {
        g.querySelector('[data-option-label]').textContent = sel[gi] || '';
        g.querySelectorAll('.size-btn').forEach((b) => {
          const trial = sel.slice(); trial[gi] = b.dataset.optionValue;
          const match = product.variants.find((v) => v.options.every((o, i) => o === trial[i]));
          b.classList.toggle('unavailable', !match || !match.available);
        });
      });
      if (!variant) { addBtn.disabled = true; addBtn.textContent = 'UNAVAILABLE'; return; }
      idInput.value = variant.id;
      priceEl.textContent = money(variant.price);
      addBtn.disabled = !variant.available;
      addBtn.textContent = variant.available ? 'ADD TO CART' : 'SOLD OUT';
      if (variant.featured_image && mainImg) { mainImg.src = variant.featured_image.src; mainImg.removeAttribute('srcset'); }
      const url = new URL(window.location.href); url.searchParams.set('variant', variant.id);
      window.history.replaceState({}, '', url);
    }

    groups.forEach((g) => g.querySelectorAll('.size-btn').forEach((b) => b.addEventListener('click', () => {
      g.querySelectorAll('.size-btn').forEach((x) => { const on = x === b; x.classList.toggle('on', on); x.setAttribute('aria-pressed', on); });
      update();
    })));
    if (groups.length) update();

    pdp.querySelectorAll('[data-qty]').forEach((b) => b.addEventListener('click', () => {
      qtyInput.value = Math.min(10, Math.max(1, (Number(qtyInput.value) || 1) + Number(b.dataset.qty)));
    }));

    pdp.querySelectorAll('[data-thumb]').forEach((b) => b.addEventListener('click', () => {
      pdp.querySelectorAll('[data-thumb]').forEach((x) => x.classList.toggle('active', x === b));
      if (mainImg) { mainImg.src = b.dataset.thumb; mainImg.removeAttribute('srcset'); }
    }));

    form.addEventListener('submit', (e) => {
      e.preventDefault();
      addBtn.disabled = true;
      addToCart(idInput.value, qtyInput.value)
        .catch((err) => alertError(addBtn, err))
        .finally(() => { update(); if (!groups.length) addBtn.disabled = false; });
    });
  }
})();
